import React from "react";

const Mint = () => {
  return <div>Mint</div>;
};

export default Mint;
