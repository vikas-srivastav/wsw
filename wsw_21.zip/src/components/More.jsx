import React from "react";

const More = () => {
  return <div>More</div>;
};

export default More;
