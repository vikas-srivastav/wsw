import React from "react";

const Staking = () => {
  return <div>Staking</div>;
};

export default Staking;
